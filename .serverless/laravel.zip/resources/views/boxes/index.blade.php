@extends('layouts.app')

@section('content')
<boxes></boxes>
@endsection

